# Examples of Salesforce Lightning Components
 
## Circular Progress bar Lightning Components example
[Blog post explaining component](http://www.jitendrazaa.com/blog/salesforce/circular-progress-bar-with-conditional-theme-salesforce-lightning-component/)
![Demo](http://www.jitendrazaa.com/blog/wp-content/uploads/2016/12/Circuar-Progress-Bar-v2-1.gif "Circular Progress bar Lightning Components")
