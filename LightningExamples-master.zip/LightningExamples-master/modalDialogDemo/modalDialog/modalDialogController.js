({
    defaultCloseAction : function(component, event, helper) {
        component.destroy();
    }
})