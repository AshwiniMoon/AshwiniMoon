# Salesforce Lightning Lookup component

[Check this blog post for complete information](http://www.jitendrazaa.com/blog/salesforce/lookup-component-in-salesforce-lightning/)

![Salesforce Lightning Lookup Component](http://www.jitendrazaa.com/blog/wp-content/uploads/2017/07/Lookup-Component.gif)
