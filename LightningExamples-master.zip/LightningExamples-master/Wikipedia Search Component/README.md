# Examples of Salesforce Lightning Components

### Lightning Component for Wikipedia search

[Blog post explaining component](http://www.jitendrazaa.com/blog/salesforce/lightning-component-for-wikipedia-search/) & [Youtube Video](https://www.youtube.com/watch?v=MXdVHL5cw-k)

![Demo](http://www.jitendrazaa.com/blog/wp-content/uploads/2016/01/Salesforce-Lightning-Component-for-Wikipedia-Search-624x467.png "Lightning Component for Wikipedia search")