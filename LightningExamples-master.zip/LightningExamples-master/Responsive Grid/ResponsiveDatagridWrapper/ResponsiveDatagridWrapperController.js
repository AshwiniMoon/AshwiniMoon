({
	doInit : function(component, event, helper) {
		helper.callServer(component);
	}
})